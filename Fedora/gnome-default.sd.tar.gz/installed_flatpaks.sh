flatpak install --system com.google.Chrome -y
flatpak install --system com.mattjakeman.ExtensionManager -y
flatpak install --system dev.vencord.Vesktop -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
flatpak install --system io.missioncenter.MissionCenter -y
flatpak install --system org.chromium.Chromium -y
